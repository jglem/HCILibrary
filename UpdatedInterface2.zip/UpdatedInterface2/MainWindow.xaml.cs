﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Page
    {
        public MainWindow()
        {
            InitializeComponent();      
        }

      


        private void checkOutButtonClick1(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("CheckOut.xaml", UriKind.Relative));
            // Main.NavigationService.Navigate(new CheckOut());
            //HomeScreen.Visibility = Visibility.Collapsed;
            //Toolbar.Visibility = Visibility.Collapsed;
      

        }

        
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Main.Navigate(new Browse());
            HomeScreen.Visibility = Visibility.Collapsed;

        }

        private void signInButton_Click(object sender, RoutedEventArgs e)
        {
            signInPopUp.IsOpen = true;
            signInPopUp.StaysOpen = true;
            graybg.Visibility = Visibility.Visible;
        }
        private void backButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate back one page from this page, if there is an entry
            // in back navigation history
            if (this.NavigationService.CanGoBack)
            {
                this.NavigationService.GoBack();
            }
            else
            {
                MessageBox.Show("No entries in back navigation history.");
            }
        }
        private void forwardButton_Click(object sender, RoutedEventArgs e)
        {
            if (this.NavigationService.CanGoForward)
            {
                this.NavigationService.GoForward();
            }
            else
            {
                MessageBox.Show("No entries in forward navigation history.");
            }
        }
        private void profileButton_Click(object sender, RoutedEventArgs e) {

        }
        private void signInConfirmButton_Click(object sender, RoutedEventArgs e)
        {
            if (libraryNumTextbox.Text.Equals("admin") && passwordTextbox.Text.Equals("admin"))
            {
                signInPopUp.IsOpen = false;
                signInPopUp.StaysOpen = false;
                graybg.Visibility = Visibility.Hidden;
                libraryNumTextbox.Text = "";
                passwordTextbox.Text = "";
                incorrectLabel.Visibility = Visibility.Hidden;

                Main.Navigate(new Profile());
                HomeScreen.Visibility = Visibility.Hidden;

                signInButton.Visibility = Visibility.Hidden;
                profileButton.Visibility = Visibility.Visible;

                finesButton.Visibility = Visibility.Visible;
                //Need to link with the real user name
                profileButton.Content = "Wade C.";
            }
            else
            {
                incorrectLabel.Visibility = Visibility.Visible;
            }
        }

        private void signInExitButton_Click(object sender, RoutedEventArgs e)
        {
            signInPopUp.IsOpen = false;
            signInPopUp.StaysOpen = false;
            graybg.Visibility = Visibility.Hidden;
            libraryNumTextbox.Text = "";
            passwordTextbox.Text = "";
            incorrectLabel.Visibility = Visibility.Hidden;
        }
    }
}
