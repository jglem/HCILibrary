﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for CheckOut.xaml
    /// </summary>
    public partial class CheckOut : Page
    {

        private List<string> bookTitles = new List<string>();
        private List<string> booktitles = new List<string>();
        private bool scanning = false;
        private int count = 0;
        private Grid toolbar;
        private Profile profile;
        public CheckOut(Profile profile_)
        {
            InitializeComponent();
            this.profile = profile_;
            //Sample Checked out
            bookTitles.Add("Night School: A jack Reacher Novel");
            bookTitles.Add("Truly Madly Guilty");
            bookTitles.Add("When Breath Becomes Air");

        }

        private void button_Scan_Click(object sender, RoutedEventArgs e)
        {
            scanning = true;

            if (count < bookTitles.Count)
            {
                exitButton.Content = "FINISH";

                msgBlock.Text = "Continue Scanning Next Item \n or \n Press FINISH";

                SolidColorBrush newBackground = new SolidColorBrush(Colors.White);


                StackPanel1.Background = newBackground;

                var newTextBox = new TextBox();
                newTextBox.Height = 41;
                newTextBox.TextWrapping = System.Windows.TextWrapping.Wrap;
                if (count == bookTitles.Count - 1)
                    button_Scan.IsEnabled = false;
                if (bookTitles.Count > 0)
                {
                    newTextBox.Text = bookTitles[count];
                }
                else
                {
                    newTextBox.Text = "text";
                }
                newTextBox.FontSize = 20;
                newTextBox.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0xA7, 0XD4, 0X81));

                StackPanel1.Children.Add(newTextBox);
                count++;
            }
            else
            {
                button_Scan.Visibility = Visibility.Collapsed;
            }


        }

        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            DateTime date = DateTime.Now;
            DateTime due = date.AddDays(21.0);
            if (scanning == false)
            {
                checkoutGrid.Visibility = Visibility.Collapsed;
                checkout_popup.IsOpen = false;

                this.NavigationService.GoBack();
                toolbar.Visibility = Visibility.Visible;
            }
            else
            {
                checkout_popup.IsOpen = true;
                bg.Visibility = Visibility.Visible;


                profile.checkout_list.Add(profile.makeData("0123", bookTitles[0], date.ToString("MM/dd/yyyy"), due.ToString("MM/dd/yyyy"), "0"));
                profile.checkout_list.Add(profile.makeData("1343", bookTitles[1], date.ToString("MM/dd/yyyy"), due.ToString("MM/dd/yyyy"), "0"));
                profile.checkout_list.Add(profile.makeData("3153", bookTitles[2], date.ToString("MM/dd/yyyy"), due.ToString("MM/dd/yyyy"), "0"));

                //bookTitles
            }

        }

        private void Yes_Click(object sender, RoutedEventArgs e)
        {
            checkoutGrid.Visibility = Visibility.Collapsed;
            checkout_popup.IsOpen = false;
            this.NavigationService.Navigate(profile);
            toolbar.Visibility = Visibility.Visible;
        }

        private void No_Click(object sender, RoutedEventArgs e)
        {
            checkout_popup.IsOpen = false;
            bg.Visibility = Visibility.Hidden;
        }
    }
}
