﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Page
    {
        Profile theProfile;
        HomePage theHomePage;
        Browse theBrowse;
        CheckOut theCheckOut;
        private List<string> bookTitles = new List<string>();
        private bool scanning = false;
        private int count = 0;
        public MainWindow()
        {
            InitializeComponent();
            theProfile = new Profile();
            theHomePage = new HomePage();
            theBrowse = new Browse();
            Main.Navigate(theHomePage);
            ShowsNavigationUI = false;
        }

      


        private void checkOutButtonClick1(object sender, RoutedEventArgs e)
        {
            checkoutGrid.Visibility = Visibility.Visible;
            Toolbar.Visibility = Visibility.Collapsed;
            Main.Visibility = Visibility.Collapsed;
            //HomeScreen.Visibility = Visibility.Collapsed;
            //Toolbar.Visibility = Visibility.Collapsed;
      

        }

        
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Main.Navigate(theBrowse);
            //HomeScreen.Visibility = Visibility.Collapsed;

        }

        private void signInButton_Click(object sender, RoutedEventArgs e)
        {
            signInPopUp.IsOpen = true;
            signInPopUp.StaysOpen = true;
            graybg.Visibility = Visibility.Visible;
            
        }
        private void backButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate back one page from this page, if there is an entry
            // in back navigation history
            if (this.NavigationService.CanGoBack)
            {
                this.NavigationService.GoBack();
            }
            else
            {
                MessageBox.Show("No entries in back navigation history.");
            }
        }
        private void forwardButton_Click(object sender, RoutedEventArgs e)
        {
            if (this.NavigationService.CanGoForward)
            {
                this.NavigationService.GoForward();
            }
            else
            {
                MessageBox.Show("No entries in forward navigation history.");
            }
        }
        private void profileButton_Click(object sender, RoutedEventArgs e) {

        }
        private void signInConfirmButton_Click(object sender, RoutedEventArgs e)
        {
            if (libraryNumTextbox.Text.Equals("admin") && passwordTextbox.Text.Equals("admin"))
            {
                signInPopUp.IsOpen = false;
                signInPopUp.StaysOpen = false;
                graybg.Visibility = Visibility.Hidden;
                libraryNumTextbox.Text = "";
                passwordTextbox.Text = "";
                incorrectLabel.Visibility = Visibility.Hidden;

                //theProfile = new Profile();
                //Main.Navigate(theProfile);
                //HomeScreen.Visibility = Visibility.Hidden;

                signInButton.Visibility = Visibility.Hidden;
                profileCB.Visibility = Visibility.Visible;

                finesButton.Visibility = Visibility.Visible;
                //Need to link with the real user name

            }
            else
            {
                incorrectLabel.Visibility = Visibility.Visible;
            }
        }

        private void signInExitButton_Click(object sender, RoutedEventArgs e)
        {
            signInPopUp.IsOpen = false;
            signInPopUp.StaysOpen = false;
            graybg.Visibility = Visibility.Hidden;
            libraryNumTextbox.Text = "";
            passwordTextbox.Text = "";
            incorrectLabel.Visibility = Visibility.Hidden;
        }

        private void SignOut_Selected(object sender, RoutedEventArgs e)
        {
            signInButton.Visibility = Visibility.Visible;
            profileCB.Visibility = Visibility.Hidden;
            finesButton.Visibility = Visibility.Hidden;

            object currentPage = NavigationService.CurrentSource;

            if (Main.Content == theProfile)
            {
                if (this.NavigationService.CanGoBack)
                {
                    this.NavigationService.GoBack();
                }
                else
                {
                    //HomeScreen.Visibility = Visibility.Visible;
                    //theProfile.Visibility = Visibility.Hidden;
                }
            }

        }

        private void CheckedOut_Selected(object sender, RoutedEventArgs e)
        {

            Main.Navigate(theProfile);
            theProfile.CheckedOutTab.IsSelected = true;
            //HomeScreen.Visibility = Visibility.Hidden;
        }

        private void Holds_Selected(object sender, RoutedEventArgs e)
        {
            Main.Navigate(theProfile);
            theProfile.HoldsTab.IsSelected = true;
            
        }

        private void Fines_Selected(object sender, RoutedEventArgs e)
        {
            Main.Navigate(theProfile);
            theProfile.FinesTab.IsSelected = true;
        }

        private void button_Scan_Click(object sender, RoutedEventArgs e)
        {
            scanning = true;
            if (this.count <= 5)
            {
                exitButton.Content = "FINISH";

                msgBlock.Text = "Continue Scanning Next Item \n or \n Press FINISH";

                SolidColorBrush newBackground = new SolidColorBrush(Colors.White);

                StackPanel1.Background = newBackground;

                var newTextBox = new TextBox();
                newTextBox.Height = 41;
                newTextBox.TextWrapping = System.Windows.TextWrapping.Wrap;
                if (bookTitles.Count > 0)
                {
                    newTextBox.Text = bookTitles[0];
                    bookTitles.RemoveAt(0);
                }
                else
                {
                    newTextBox.Text = "text";
                }
                newTextBox.FontSize = 20;
                newTextBox.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0xA7, 0XD4, 0X81));

                StackPanel1.Children.Add(newTextBox);
                count++;
            }
            else
            {
                button_Scan.Visibility = Visibility.Collapsed;
            }


        }

        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            if (scanning == false)
            {
                checkoutGrid.Visibility = Visibility.Collapsed;
                checkout_popup.IsOpen = false;
                Toolbar.Visibility = Visibility.Visible;
                Main.Visibility = Visibility.Visible;

                /*
                if (this.NavigationService.CanGoBack)
                {
                    this.NavigationService.GoBack();
                }
                else
                {
                    this.NavigationService.Navigate(new MainWindow());
                }
                */
                //toolbar.Visibility = Visibility.Visible;
            }
            else
            {
                checkout_popup.IsOpen = true;
                bg.Visibility = Visibility.Visible;
            }

        }

        private void Yes_Click(object sender, RoutedEventArgs e)
        {
            checkoutGrid.Visibility = Visibility.Collapsed;
            checkout_popup.IsOpen = false;
            Toolbar.Visibility = Visibility.Visible;
            Main.Visibility = Visibility.Visible;
            bg.Visibility = Visibility.Hidden;
            //this.NavigationService.GoBack();
            //toolbar.Visibility = Visibility.Visible;
        }

        private void No_Click(object sender, RoutedEventArgs e)
        {
            checkout_popup.IsOpen = false;
            bg.Visibility = Visibility.Hidden;
        }
    }
}

    



